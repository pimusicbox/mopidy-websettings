var settingsEnabled = true;
var shutdownEnabled = true;